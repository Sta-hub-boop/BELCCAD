
let currentSlide = 0;
const slides = document.querySelectorAll('.slide1, .slide2');
const totalSlides = slides.length;

function moveSlide(step) {
    currentSlide += step;

    if (step == 1 || step == -1) {
        if (currentSlide < 0) {
            currentSlide = totalSlides - 2;
        } else if (currentSlide >= totalSlides - 1) {
            currentSlide = 0;
        }
    } else {
        if (currentSlide < -1) {
            currentSlide = totalSlides - 2;
        } else if (currentSlide == totalSlides - 1) {
            currentSlide = currentSlide - 1;
        } else if (currentSlide > totalSlides - 1) {
            currentSlide = 0;
        } else if (currentSlide == -1) {
            currentSlide = currentSlide + 1;
        }
    }


    const offset = -currentSlide * 55;
    document.querySelector('.slider_container').style.transform = `translateX(${offset}%)`;
}



function showPopup(id) {
    document.querySelector('.backgroundClose').style.display = 'block';
    document.getElementById(id).style.display = 'flex';
}

function closePopup(id) {
    document.getElementById(id).style.display = 'none';
    document.querySelector('.backgroundClose').style.display = 'none';
}

function closeAllPopup() {
    document.querySelectorAll('.popup, .popup1').forEach(function(popup) {
        popup.style.display = 'none';
    });
    document.querySelector('.backgroundClose').style.display = 'none';
}

window.addEventListener('click', function(event) {
    if (event.target.classList.contains('backgroundClose')) {
        closeAllPopup();
    }
});


