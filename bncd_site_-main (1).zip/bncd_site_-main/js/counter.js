
document.addEventListener("DOMContentLoaded", () => {
    const counters = document.querySelectorAll('.statCounter');

    // Функция для анимации отсчета
    function animateCounter(element, target) {
        let start = 0;
        const increment = Math.ceil(target / 100); // Частота обновления, 100 шагов
        const duration = 1000; // Продолжительность анимации в миллисекундах
        const stepTime = Math.abs(Math.floor(duration / (target / increment)));

        const timer = setInterval(() => {
            start += increment;
            if (start >= target) {
                element.innerText = target;
                clearInterval(timer);
            } else {
                element.innerText = start;
            }

            // add plus after number
            let rezNumber = element.innerText
            if (element.getAttribute('id') == 'statCounterPlus' && rezNumber == target) {
                element.innerText = rezNumber + '+'
            }

        }, stepTime);
        
        
    }

    // Intersection Observer для отслеживания видимости
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const counter = entry.target;
                const target = parseInt(counter.getAttribute('data-target'), 10);
                if (!counter.classList.contains('animated')) {
                    animateCounter(counter, target);
                    counter.classList.add('animated');
                }
                observer.unobserve(counter); // Остановить наблюдение после начала анимации
            }
        });
    }, {threshold: 0.5}); // Порог видимости 50%

    counters.forEach(counter => {
        observer.observe(counter);
    });
});


