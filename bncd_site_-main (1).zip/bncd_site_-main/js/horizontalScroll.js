

$(document).ready(function(){

    rButton = $("#prRightButton");
    lButton = $("#prLeftButton");
    slider = $("#practiceSlider")

    let count = $('.prItemCard').length
    let sliderWidth = (count * 350 + (count - 1) * 30) - 900
    console.log(sliderWidth)

    sliderPos = slider.scrollLeft()

    $("#1").css("background", "red")
    $("#2").css("background", "red")
    $("#3").css("background", "red")

    rButton.on('click', function() {
        sliderPos = sliderPos - 700
        if(sliderPos < 0) sliderPos = 0
        slider.scrollLeft(sliderPos)
    })

    lButton.on('click', function() {
        sliderPos = sliderPos + 700
        if(sliderPos > sliderWidth) sliderPos = sliderWidth
        slider.scrollLeft(sliderPos)
    })

});


